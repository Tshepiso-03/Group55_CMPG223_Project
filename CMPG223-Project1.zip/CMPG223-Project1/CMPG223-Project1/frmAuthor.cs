﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_Project1
{
    public partial class frmAuthor : Form
    {
        //string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Models\GitProject\CMPG223-Project1\CMPG223-Project1\CMPG223-Project1\AuthorDatabase.mdf;Integrated Security=True";
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Movies\CMPG223-Project1\CMPG223-Project1\LibraryDatabase.mdf;Integrated Security=True";
        public frmAuthor()
        {
            InitializeComponent();
            LoadAuthorGrid();

            cmbSearchBy.SelectedIndex = 0; // Default to FirstName
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateAuthorForm())
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Author (FirstName, LastName, Biography, Nationality) " +
                                   "VALUES (@FirstName, @LastName, @Biography, @Nationality)";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@Biography", txtBio.Text);
                    cmd.Parameters.AddWithValue("@Nationality", txtNationality.Text);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Author added successfully!");
                        LoadAuthorGrid();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
                //LoadMemberGrid();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("Please enter the First Name of the Author to update.");
                return;
            }

            // Get updated values from form
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string bio = txtBio.Text;
            string nationality = txtNationality.Text;


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Update the first member with this FirstName
                string sql = @"
                UPDATE TOP(1) Author
                SET LastName = @LastName,
                    Biography = @Biography,
                    Nationality = @Nationality
                WHERE FirstName = @FirstName";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@FirstName", firstName);
                cmd.Parameters.AddWithValue("@LastName", lastName);
                cmd.Parameters.AddWithValue("@Biography", bio);
                cmd.Parameters.AddWithValue("@Nationality", nationality);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Author updated successfully.");
                    LoadAuthorGrid(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("No Author found with that First Name.");
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("Please enter a First Name to delete.");
                return;
            }

            string firstNameToDelete = txtFirstName.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Delete the first member matching the first name
                string sql = @"DELETE TOP(1) FROM Author WHERE FirstName = @FirstName";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@FirstName", firstNameToDelete);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Author deleted successfully.");
                    LoadAuthorGrid(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("No Author found with that First Name.");
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 adminForm = new Form1();
            adminForm.Show();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string selectedField = cmbSearchBy.SelectedItem?.ToString();

                if (string.IsNullOrWhiteSpace(selectedField)) return;

                using (SqlConnection cnn = new SqlConnection(connectionString))
                {
                    string sql = $"SELECT * FROM Author WHERE {selectedField} LIKE @searchText";

                    using (SqlCommand command = new SqlCommand(sql, cnn))
                    {
                        command.Parameters.AddWithValue("@searchText", "%" + txtSearch.Text + "%");

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataSet ds = new DataSet();
                        adapter.Fill(ds, "Author");

                        dgvAuthor.DataSource = ds;
                        dgvAuthor.DataMember = "Author";
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void dgvAuthor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; // Ignore header clicks

            DataGridViewRow row = dgvAuthor.Rows[e.RowIndex];

            // Populate text boxes
            txtFirstName.Text = row.Cells["FirstName"].Value.ToString();
            txtLastName.Text = row.Cells["LastName"].Value.ToString();
            txtBio.Text = row.Cells["Biography"].Value.ToString();
            txtNationality.Text = row.Cells["Nationality"].Value.ToString();
        }

        private void tntBook_Click(object sender, EventArgs e)
        {
            frmBook bookForm = new frmBook();
            bookForm.Show();
        }
        private void LoadAuthorGrid()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    //conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    DataSet ds = new DataSet();

                    string sql = @"SELECT * FROM Author";
                    SqlCommand command = new SqlCommand(sql, conn);

                    //Filling the dataset
                    adapter.SelectCommand = command;
                    adapter.Fill(ds, "Author");

                    //Adding the data into the data grid
                    dgvAuthor.DataSource = ds;
                    dgvAuthor.DataMember = "Author";

                    //Closing the connection to the database
                    //conn.Close();

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private bool ValidateAuthorForm()
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtBio.Text) ||
                string.IsNullOrWhiteSpace(txtNationality.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return false;
            }
            return true;
        }
        private void ClearForm()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtBio.Clear();
            txtNationality.Clear();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Form1 adminForm = new Form1();
            adminForm.Show();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtFirstName.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtFirstName.Text = txtFirstName.Text.Remove(txtFirstName.Text.Length - 1);
                txtFirstName.SelectionStart = txtFirstName.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtFirstName, "First Name must only contain letters.");
            }
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtLastName.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtLastName.Text = txtLastName.Text.Remove(txtLastName.Text.Length - 1);
                txtLastName.SelectionStart = txtLastName.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtLastName, "Last Name must only contain letters.");
            }
        }

        private void txtNationality_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtBio.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtNationality.Text = txtNationality.Text.Remove(txtNationality.Text.Length - 1);
                txtNationality.SelectionStart = txtNationality.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtNationality, "Nationality must only contain letters.");
            }
        }

        private void txtBio_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtBio.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtBio.Text = txtBio.Text.Remove(txtBio.Text.Length - 1);
                txtBio.SelectionStart = txtBio.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtBio, "Biography must only contain letters.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
