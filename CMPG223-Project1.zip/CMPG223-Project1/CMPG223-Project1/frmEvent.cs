﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_Project1
{
    public partial class frmEvents : Form
    {
        //string connStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Models\GitProject\CMPG223-Project1\CMPG223-Project1\CMPG223-Project1\EventDatabase.mdf;Integrated Security=True";
        string connStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Movies\CMPG223-Project1\CMPG223-Project1\LibraryDatabase.mdf;Integrated Security=True";
        SqlConnection conn;
        public frmEvents()
        {
            InitializeComponent();
            LoadCombobox();
            JoinEvents();
            LoadReader();
            //LoadEvents();
            LoadEventsGrid();
        }
        private void LoadEventsGrid()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    //conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    DataSet ds = new DataSet();

                    string sql = @"SELECT * FROM Events";
                    SqlCommand command = new SqlCommand(sql, conn);

                    //Filling the dataset
                    adapter.SelectCommand = command;
                    adapter.Fill(ds, "Events");

                    //Adding the data into the data grid
                    dgvEvents.DataSource = ds;
                    dgvEvents.DataMember = "Events";

                    //Closing the connection to the database
                    //conn.Close();

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error loading datatable!!",ex.Message);
            }
        }
        private void dgvEvents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvEvents.Rows[e.RowIndex].Cells["Date"].Value != null)
            {
                DataGridViewRow row = dgvEvents.Rows[e.RowIndex];
                dtpDate.Value = Convert.ToDateTime(row.Cells["Date"].Value);
                txtBook.Text = row.Cells["Book"].Value.ToString();
                txtAttendees.Text = row.Cells["Attendees"].Value.ToString();
            }

        }
        private bool ValidateEventForm()
        {
            if (string.IsNullOrWhiteSpace(txtBook.Text) ||
                string.IsNullOrWhiteSpace(txtAttendees.Text) ||
                cbxReader.SelectedValue == null)
            {
                MessageBox.Show("Please fill in all fields.");
                return false;
            }
            return true;
        }
        private void LoadCombobox()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string sqlReader = "SELECT ReaderId, Email FROM Readers";
                    SqlDataAdapter daReader = new SqlDataAdapter(sqlReader, conn);

                    DataSet dsReader = new DataSet();
                    daReader.Fill(dsReader, "Readers");

                    cbxReader.DataSource = dsReader.Tables["Readers"];
                    cbxReader.DisplayMember = "Email";
                    cbxReader.ValueMember = "ReaderId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading combo box: ", ex.Message);
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            try
            {
                if (ValidateEventForm())
                {
                    //return;
                    if (cbxReader.SelectedValue == null)
                    {
                        MessageBox.Show("Please select a reader.");
                        return;
                    }

                    int readerId = Convert.ToInt32(cbxReader.SelectedValue);

                    DateTime date = dtpDate.Value;

                    string query = "INSERT INTO Events (ReaderId, Date, Book, Attendees) VALUES (@ReaderId, @Date, @Book, @Attendees)";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    //cmd.Parameters.AddWithValue("LoanId",)
                    cmd.Parameters.AddWithValue("@ReaderId", readerId);
                    cmd.Parameters.AddWithValue("@Date", date);
                    cmd.Parameters.AddWithValue("@Book", txtBook.Text);
                    cmd.Parameters.AddWithValue("@Attendees", int.Parse(txtAttendees.Text));

                    conn.Open();

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Event inserted successfully!");
                    //LoadEvents();
                    JoinEvents();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert failed: " + ex.Message);
                conn.Close();
            }
            
             
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                string query = "UPDATE Events SET ReaderId=@ReaderId, Date=@Date, Attendees=@Attendees WHERE Book=@Book";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ReaderId", cbxReader.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@Date", dtpDate.Value);
                cmd.Parameters.AddWithValue("@Book", txtBook.Text);
                cmd.Parameters.AddWithValue("@Attendees", int.Parse(txtAttendees.Text));

                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Event updated successfully!");
                JoinEvents();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message);
                conn.Close();
            }
        }
        /*private void LoadEvents()
        {
            conn = new SqlConnection(connStr);
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = @"SELECT E.EventsId,
                            R.Email AS ReaderEmail,
                            E.Date,
                            E.Book,
                            E.Attendees
                        FROM Events E
                        INNER JOIN Readers R ON E.ReaderId = R.ReaderId";

                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "Events");
                    dgvEvents.DataSource = ds;
                    dgvEvents.DataMember = "Events";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading events: " + ex.Message);
                conn.Close();
            }
        }*/
        private void JoinEvents()
        {
            string query = @"SELECT 
                            E.EventsId,
                            R.Email,
                            E.Date,
                            E.Book,
                            E.Attendees
                        FROM Events E
                        INNER JOIN Readers R ON E.ReaderId = R.ReaderId";
            using(conn = new SqlConnection(connStr))
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataSet ds = new DataSet();

                    da.Fill(ds, "Events");
                    dgvEvents.DataSource = ds;
                    dgvEvents.DataMember = "Events";
                }
                catch(SqlException ex)
                {
                    MessageBox.Show("Error joining tables: ", ex.Message);
                }
            }
        }
        private void LoadReader()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string sql = @"SELECT ReaderId, Email FROM Readers";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cbxReader.DataSource = dt;
                    cbxReader.DisplayMember = "Email";
                    cbxReader.ValueMember = "ReaderId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading readers: ", ex.Message);
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                string query = "DELETE FROM Events WHERE Book=@Book";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Book", txtBook.Text);

                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Event deleted successfully!");
                JoinEvents();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed: " + ex.Message);
                conn.Close();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 adminForm = new Form1();
            adminForm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtAttendees_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // ignore the key
                                  // MessageBox.Show("Phone number must only contain digits.");
                errorProvider1.SetError(txtAttendees, "Attendees must only contain digits.");
            }
        }

        private void txtBook_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtBook.Text, @"^[\w\s\p{P}]{2,100}$"))
            {
                errorProvider1.SetError(txtBook, "Invalid book title format!");
            }
            else
            {
                errorProvider1.SetError(txtBook, "");
            }

        }
    }
}
