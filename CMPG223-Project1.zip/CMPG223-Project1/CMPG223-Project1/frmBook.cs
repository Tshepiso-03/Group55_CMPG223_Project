﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_Project1
{
    public partial class frmBook : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Movies\CMPG223-Project1\CMPG223-Project1\LibraryDatabase.mdf;Integrated Security=True";
        // string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Models\GitProject\CMPG223-Project1\CMPG223-Project1\CMPG223-Project1\BookDatabase.mdf;Integrated Security=True";
        public frmBook()
        {
            InitializeComponent();
            ValidateBookForm();
            LoadBookGrid();
            LoadComboBox();

            cmbSearchBy.SelectedIndex = 0; // Default to FirstName
        }

        private void btnAddBook_Click(object sender, EventArgs e)
        {
            if (ValidateBookForm())
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    bool status = cbxStatu1.SelectedItem != null && cbxStatu1.SelectedItem.ToString() == "Yes";

                    string query = "INSERT INTO Books (Title, Genre, Author, Phone_No, Published_Year, Status) " +
                                   "VALUES (@Title, @Genre, @Author, @Phone_No, @Published_Year, @Status)";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Title", txtTitle1.Text);
                    cmd.Parameters.AddWithValue("@Genre", txtGenre1.Text);
                    cmd.Parameters.AddWithValue("@Author", txtAuthor11.Text);
                    cmd.Parameters.AddWithValue("@Phone_No", txtPhoneNum.Text);
                    cmd.Parameters.AddWithValue("@Published_Year", txtYear.Text);
                    cmd.Parameters.AddWithValue("@Status", status);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Book added successfully!");
                        LoadBookGrid();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
        private void ClearForm()
        {
            txtTitle1.Clear();
            txtGenre1.Clear();
            txtAuthor11.Clear();
            txtYear.Clear();
            txtPhoneNum.Clear();
            cbxStatu1.SelectedIndex = -1;
        }
        private void LoadComboBox()
        {
            cbxStatu1.Items.Clear();
            cbxStatu1.Items.AddRange(new string[] { "Yes", "No" });
        }
        private void LoadBookGrid()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    DataSet ds = new DataSet();

                    string sql = @"SELECT * FROM Books";
                    SqlCommand command = new SqlCommand(sql, conn);

                    //Filling the dataset
                    adapter.SelectCommand = command;
                    adapter.Fill(ds, "Books");

                    //Adding the data into the data grid
                    dgvBooks.DataSource = ds;
                    dgvBooks.DataMember = "Books";

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private bool ValidateBookForm()
        {
            if (string.IsNullOrWhiteSpace(txtTitle1.Text) ||
                string.IsNullOrWhiteSpace(txtGenre1.Text) ||
                string.IsNullOrWhiteSpace(txtAuthor11.Text) ||
                string.IsNullOrWhiteSpace(txtPhoneNum.Text) ||
                string.IsNullOrWhiteSpace(txtYear.Text) ||
                cbxStatu1.SelectedItem == null)
            {
                MessageBox.Show("Please fill in all fields.");
                return false;
            }
            return true;
        }

        private void btnUpdateBook_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle1.Text))
            {
                MessageBox.Show("Please enter the Title of the Book to update.");
                return;
            }

            // Get updated values from form
            string title = txtTitle1.Text;
            string genre = txtGenre1.Text;
            string author = txtAuthor11.Text;
            string phoneNo = txtPhoneNum.Text;
            string year = txtYear.Text;


            // Convert ComboBox selections to boolean
            bool status = cbxStatu1.SelectedItem != null && cbxStatu1.SelectedItem.ToString() == "Yes";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Update the first member with this FirstName
                string sql = @"
                UPDATE TOP(1) Books
                SET Genre = @Genre,
                    Author = @Author,
                    Phone_No = @Phone_No,
                    Published_Year = @Published_Year,
                    Status = @Status
                WHERE Title = @Title";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@Genre", genre);
                cmd.Parameters.AddWithValue("@Author", author);
                cmd.Parameters.AddWithValue("@Phone_No", phoneNo);
                cmd.Parameters.AddWithValue("@Published_Year", year);
                cmd.Parameters.AddWithValue("@Status", status);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Book updated successfully.");
                    LoadBookGrid(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("No Book found with that Title.");
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string selectedField = cmbSearchBy.SelectedItem?.ToString();

                if (string.IsNullOrWhiteSpace(selectedField)) return;

                using (SqlConnection cnn = new SqlConnection(connectionString))
                {
                    string sql = $"SELECT * FROM Books WHERE {selectedField} LIKE @searchText";

                    using (SqlCommand command = new SqlCommand(sql, cnn))
                    {
                        command.Parameters.AddWithValue("@searchText", "%" + txtSearch.Text + "%");

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataSet ds = new DataSet();
                        adapter.Fill(ds, "Books");

                        dgvBooks.DataSource = ds;
                        dgvBooks.DataMember = "Books";
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void dgvBooks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; // Ignore header clicks

            DataGridViewRow row = dgvBooks.Rows[e.RowIndex];

            // Populate text boxes
            txtTitle1.Text = row.Cells["Title"].Value.ToString();
            txtGenre1.Text = row.Cells["Genre"].Value.ToString();
            txtAuthor11.Text = row.Cells["Author"].Value.ToString();
            txtPhoneNum.Text = row.Cells["Phone_No"].Value.ToString();
            txtYear.Text = row.Cells["Published_Year"].Value.ToString();

            // Populate ComboBoxes (Yes/No)
            cbxStatu1.Text = Convert.ToBoolean(row.Cells["Status"].Value) ? "Yes" : "No";
        }

        private void cbxStatu1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check Status selection
            if (cbxStatu1.SelectedItem == null)
            {
                MessageBox.Show("Please select Yes or No for Loan Book.");
                return; // stop further execution
            }

            // Safe conversion to string and boolean
            string status = cbxStatu1.SelectedItem?.ToString();
            bool bookValue = status == "Yes";

            // Message and optionally enable/disable related controls (not the ComboBox itself)
            if (bookValue)
            {
                MessageBox.Show("You have chosen to loan a book.");
            }
            else
            {
                MessageBox.Show("You have chosen not to loan a book.");
            }
        }

        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle1.Text))
            {
                MessageBox.Show("Please enter a Title to delete.");
                return;
            }

            string titleToDelete = txtTitle1.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Delete the first member matching the first name
                string sql = @"DELETE TOP(1) FROM Books WHERE Title = @Title";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", titleToDelete);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Book deleted successfully.");
                    LoadBookGrid(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("No Book found with that Book.");
                }
            }
        }

        private void btnClear1_Click(object sender, EventArgs e)
        {
            txtTitle1.Clear();
            txtGenre1.Clear();
            cbxStatu1.Items.Clear();
            txtYear.Clear();
            txtAuthor11.Clear();
            txtPhoneNum.Clear();
        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            Form1 adminForm = new Form1();
            adminForm.ShowDialog();
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtGenre1_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtGenre1.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtGenre1.Text = txtGenre1.Text.Remove(txtGenre1.Text.Length - 1);
                txtGenre1.SelectionStart = txtGenre1.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtGenre1, "Genre must only contain letters.");
            }
        }

        private void txtAuthor11_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtAuthor11.Text, @"^[a-zA-Z]*$"))
            {
                //MessageBox.Show("First Name must only contain letters.");
                txtAuthor11.Text = txtAuthor11.Text.Remove(txtAuthor11.Text.Length - 1);
                txtAuthor11.SelectionStart = txtAuthor11.Text.Length; // keep cursor at end
                errorProvider1.SetError(txtAuthor11, "Author must only contain letters.");
            }
        }

        private void txtPhoneNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // ignore the key
                                  // MessageBox.Show("Phone number must only contain digits.");
                errorProvider1.SetError(txtPhoneNum, "Phone number must only contain digits.");
            }
        }

        private void txtYear_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // ignore the key
                                  // MessageBox.Show("Phone number must only contain digits.");
                errorProvider1.SetError(txtYear, "Year must only contain digits.");
            }
        }
    }
}
