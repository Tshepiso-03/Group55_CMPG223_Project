﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG223_Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
           
        }

        private void btnMembers_Click(object sender, EventArgs e)
        {
            frmMembers memberForm = new frmMembers();
            memberForm.Show();
        }

        private void btnAuthor_Click(object sender, EventArgs e)
        {
            frmAuthor authorForm = new frmAuthor();
            authorForm.Show();
        }

        private void btnLoan_Click(object sender, EventArgs e)
        {
            frmLoanDetails loanForm = new frmLoanDetails();
            loanForm.Show();
        }

        private void btnBooks_Click(object sender, EventArgs e)
        {
            frmBook booksForm = new frmBook();
            booksForm.Show();
        }

        private void btnReader_Click(object sender, EventArgs e)
        {
            frmReader readerForm = new frmReader();
            readerForm.Show();
        }

        private void btnEvents_Click(object sender, EventArgs e)
        {
            frmEvents eventsForm = new frmEvents();
            eventsForm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
